# Driver-Drowsiness-Detection
An AI-based Driver Drowsiness Detection system

A system which alarms the driver as soon as it detects that the driver is becoming drowsy to prevent any accident.
